import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
public class RmiServer {
    public static void main(String[] args) {
        try {
            Adder rmiobj = new AdderImp();
            Registry registry = LocateRegistry.createRegistry(1099);
            registry.bind("AddService", rmiobj);
            System.out.println("Server started and waiting for client requests...");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
