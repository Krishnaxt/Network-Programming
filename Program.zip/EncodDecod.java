import java.net.URLEncoder;
import java.net.URLDecoder;
import java.io.UnsupportedEncodingException;
public class EncodDecod {
    public static void main(String[] args) {
        String originalData = "param1=value1&param2=value2";

        // Encoding data
        try {
            String encodedData = URLEncoder.encode(originalData, "UTF-8");
            System.out.println("Encoded data: " + encodedData);
        } catch (UnsupportedEncodingException e) {
            System.out.println(e.getMessage());
        }
        // Decoding data

        try {
            String encodedData = URLEncoder.encode(originalData, "UTF-8");
            String decodedData = URLDecoder.decode(encodedData, "UTF-8");
            System.out.println("Decoded data: " + decodedData);
        } catch (UnsupportedEncodingException e) {
            System.out.println(e.getMessage());
        }

    }
}
