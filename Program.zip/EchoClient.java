import java.io.*;
import java.net.*;
import java.util.*;

public class EchoClient {
    public static void main(String[] args) throws IOException {
        Socket socket = new Socket("localhost", 8000);
        System.out.println("Connected to echo server.");
        DataInputStream in = new DataInputStream(socket.getInputStream());
        DataOutputStream out = new DataOutputStream(socket.getOutputStream());
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.print("Enter text: ");
            String message = sc.nextLine();
            out.writeUTF(message);
            out.flush();
            String response = in.readUTF();
            System.out.println("Echo from server: " + response);
        }

    }
}
