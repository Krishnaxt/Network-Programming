import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
public class SetRequestMethod {
    public static void main(String[] args) {
        try {
            URL url = new URL("https://www.example.com");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            // Set other request headers and parameters here
            BufferedReader in = new BufferedReader(new InputStreamReader(
                                  connection.getInputStream()));
            String inputLine;
            StringBuffer content = new StringBuffer();
            int responseCode = connection.getResponseCode();
            System.out.println("Response code: " + responseCode);
            while ((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }
            in.close();
            connection.disconnect();
            System.out.println("Response: " + content.toString());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
