import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.Base64;
public class BinaryServer {
    public static void main(String[] args) throws IOException {
        int port = Integer.parseInt(args[0]);
        ServerSocket serverSocket = new ServerSocket(port);
        System.out.println("Server started on port " + port);
        while (true) {
            Socket clnt = serverSocket.accept();
            System.out.println("Client connected: " + clnt);
            long currentTime = System.currentTimeMillis();
            ByteBuffer buffer = ByteBuffer.allocate(Long.BYTES);
            buffer.putLong(currentTime);
            byte[] timeBytes = buffer.array();
            String encodedTime = Base64.getEncoder().encodeToString(timeBytes);
            DataOutputStream out = new DataOutputStream(clnt.getOutputStream());
            out.writeUTF(encodedTime);
            clnt.close();
        }
    }
}
