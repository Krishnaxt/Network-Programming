import javax.net.ssl.SSLSocketFactory;
import java.net.Socket;
import java.io.*;

public class SecureClient {
    public static void main(String[] args) throws Exception {
        // Create a SSLSocketFactory object.
        SSLSocketFactory sslSocketFactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
        // Create a Socket object using the SSLSocketFactory object.
        Socket socket = sslSocketFactory.createSocket("localhost", 9000);
        // Use the Socket object to send and receive data.
        String message = "Hello, server!";
        DataInputStream in = new DataInputStream(socket.getInputStream());
        DataOutputStream out = new DataOutputStream(socket.getOutputStream());
        out.writeUTF(message);
        // Read the response from the server.
        String responseMessage = in.readUTF();
        // Print the response from the server.
        System.out.println("Server says: " + responseMessage);
    }
}