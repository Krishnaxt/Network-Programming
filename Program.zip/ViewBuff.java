import java.nio.ByteBuffer;
import java.nio.IntBuffer;

public class ViewBuff {
    public static void main(String[] args) {
        // Create a byte buffer with 8 bytes
        ByteBuffer byteBuffer = ByteBuffer.allocate(18);
        // Put some data into the byte buffer
        byteBuffer.putInt(123);
        byteBuffer.putInt(456);
        byteBuffer.flip();
        // Create an int buffer view of the byte buffer
        IntBuffer intBuffer = byteBuffer.asIntBuffer();
        // Read and print the integers from the int buffer view
        while (intBuffer.hasRemaining()) {
            System.out.println(intBuffer.get());
        }
    }
}
