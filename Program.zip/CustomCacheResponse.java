
public class CustomCacheResponse {

}
