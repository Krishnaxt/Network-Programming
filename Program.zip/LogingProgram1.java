import java.io.*;
import java.net.*;
import java.util.Date;
import java.util.logging.*;
public class LogingProgram1 {
    private static final Logger logger = Logger.getLogger(LogingProgram1.class.getName());
    public static void main(String[] args) {
        logger.info("Starting daytime server...");
        try (ServerSocket serverSocket = new ServerSocket(13)) {
            while (true) {
                try (Socket clientSocket = serverSocket.accept()) {
                    logger.info("Accepted client connection: " + clientSocket.getInetAddress());
                    Date now = new Date();
                    String response = now.toString() + "\r\n";
                    OutputStream outputStream = clientSocket.getOutputStream();
                    outputStream.write(response.getBytes());
                    logger.info("Sent response to client: " + response);
                } catch (IOException e) {
                    logger.log(Level.SEVERE, "Error handling client request: " + e.getMessage(), e);
                }
            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error starting daytime server: " + e.getMessage(), e);
        }
    }
}
