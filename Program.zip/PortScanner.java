import java.net.InetSocketAddress;
import java.net.Socket;

public class PortScanner {
    public static void main(String[] args) {
        String host = "localhost"; // Replace with the host you want to scan

        for (int port = 1; port <= 2048; port++) {
            try {
                Socket socket = new Socket();
                socket.connect(new InetSocketAddress(host, port), 1000);
                System.out.println("Port " + port + " is open");
                socket.close();
            } catch (Exception e) {
                // Port is closed or host is unreachable
            }
        }
    }
}
