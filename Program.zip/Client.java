import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) throws IOException {
        String serverAddress = "localhost";
        int port = 8080;
        Socket socket = new Socket(serverAddress, port);
        System.out.println("Connected to server at " + serverAddress + ":" + port);
        System.out.println("enter a message: ");
        Scanner sc = new Scanner(System.in);
        String msg = sc.nextLine();
        sc.close();
        DataOutputStream out = new DataOutputStream(socket.getOutputStream());
        out.writeUTF(msg);
        DataInputStream in = new DataInputStream(socket.getInputStream());
        String message = in.readUTF();
        System.out.println("Received message from server: " + message);
        socket.close();
    }
}
