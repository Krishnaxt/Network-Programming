import javax.net.ssl.*;
import java.io.*;

public class SSLServer {
    public static void main(String[] args) {
        try {
            // Set up SSL server socket
            SSLServerSocketFactory serverSocketFactory = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
            SSLServerSocket serverSocket = (SSLServerSocket) serverSocketFactory.createServerSocket(8000);

            // Set up truststore for server
            System.setProperty("javax.net.ssl.trustStore", "server.truststore");
            System.setProperty("javax.net.ssl.trustStorePassword", "aaaaaa");

            System.out.println("Server started on port 8000.");
            while (true) {
                // Wait for a client to connect
                SSLSocket socket = (SSLSocket) serverSocket.accept();
                System.out.println("Client connected: " + socket.getInetAddress());
                // Create input and output streams
                DataInputStream in = new DataInputStream(socket.getInputStream());
                DataOutputStream out = new DataOutputStream(socket.getOutputStream());
                // Read a message from the client
                String message = in.readUTF();
                System.out.println("Received message from client: " + message);
                // Send a response to the client
                out.writeUTF("Hello, client!");
                // Close the socket and server socket
                socket.close();
            }
            // serverSocket.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
/*
 * to generate the key:
 * keytool -keystore "C:\Program Files\Java\jre-1.8\lib\cacerts"
 * -import -alias https://www.facebook.com
 * -file "C:\Users\acer\Downloads\cert\demo.crt"
 */