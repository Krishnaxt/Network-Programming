import java.io.*;
import java.net.*;

public class Server {
    public static void main(String[] args) throws IOException {
        int port = 8080;
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Server started on port " + port);
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("New client connected: " + clientSocket.getInetAddress().getHostAddress());
                DataInputStream in = new DataInputStream(clientSocket.getInputStream());
                String message = in.readUTF();
                System.out.println("Received message from client: " + message);
                DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream());
                out.writeUTF("Server received message: " + message);
                clientSocket.close();
            }
        }
    }
}
