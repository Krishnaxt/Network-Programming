import java.net.*;
public class UdpScanner {
    public static void main(String[] args) {
        try {
            for (int port = 1024; port <= 65535; port++) {
                try {
                    DatagramSocket socket = new DatagramSocket(port);
                    socket.close();
                    System.out.println("Port " + port + 
                    " is available for UDP communication.");
                } catch (SocketException e) {
                    // Port is already in use
                    System.out.println("Port " + port + " is in use.");
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
