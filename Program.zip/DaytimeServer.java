
import java.io.*;
import java.net.*;
import java.util.*;

public class DaytimeServer {
    public static void main(String[] args) {
        // Get the port number from the command line argument
        int port = Integer.parseInt(args[0]);
        try {
            // Create a new server socket and bind it to the specified port
            ServerSocket serverSocket = new ServerSocket(port);
            while (true) {
                // Wait for a client to connect
                Socket clientSocket = serverSocket.accept();
                // Get the current date and time
                String date = new Date().toString();
                // Send the date and time to the client using writeUTF
                DataOutputStream outToClient = new DataOutputStream(clientSocket.getOutputStream());
                outToClient.writeUTF("Today is :" + date);
                // Close the connection
                clientSocket.close();
            }
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
