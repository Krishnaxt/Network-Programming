
import java.io.*;
import java.net.*;
import java.net.URL;
public class DemoGetMethod {
    public static void main(String[] args) {
        try {
            URL url = new URL("http://example.com/server-side-program.php?name=John&age=30");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            line= reader.readLine();
            System.out.println(line);
            reader.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
