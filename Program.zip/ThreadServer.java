import java.io.*;
import java.net.*;
import java.util.*;

public class ThreadServer {
    public static void main(String[] args) throws IOException {
        int port = Integer.parseInt(args[0]);
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Daytime server started.");
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Accepted connection from " + clientSocket.getInetAddress());
                // Create a new thread to handle the client connection
                DaytimeThread dt = new DaytimeThread(clientSocket);
                Thread thread = new Thread(dt);
                thread.start();
            }
        }
    }
}

class DaytimeThread implements Runnable {
    private final Socket clientSocket;

    public DaytimeThread(Socket clientSocket) {
        this.clientSocket = clientSocket;
    }

    public void run() {
        try {
            DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream());
            String dateTime = new Date().toString();
            out.writeUTF("Today is :" + dateTime);
            out.close();
            clientSocket.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
