import java.net.PasswordAuthentication;

public class DemoPass {
    public static void main(String[] args) {
        String username = "Admin";
        String password = "Admin123";

        PasswordAuthentication pass = new PasswordAuthentication(username, password.toCharArray());

        System.out.println("Username: " + pass.getUserName());
        System.out.println("Password: " + new String(pass.getPassword()));
    }
}