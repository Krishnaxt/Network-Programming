import java.net.*;
import java.util.*;

public class SimpleCookieExample {
    public static void main(String[] args) throws Exception {
        // Create a CookieManager with default CookiePolicy
        CookieManager manager = new CookieManager();
        CookieHandler.setDefault(manager);

        // Create URL object for the website that sets cookies
        URL url = new URL("https://www.example.com/");

        // Make HTTP request to the website
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        int responseCode = connection.getResponseCode();

        // Print response code to console
        System.out.println("Response code: " + responseCode);

        // Retrieve cookies from the cookie manager
        List<HttpCookie> cookies = manager.getCookieStore().getCookies();

        // Print all the cookies
        for (HttpCookie cookie : cookies) {
            System.out.println(cookie);
        }

        // Set a cookie in the cookie manager
        HttpCookie cookie = new HttpCookie("my_cookie", "1234");
        cookie.setDomain(".example.com");
        cookie.setPath("/");
        manager.getCookieStore().add(url.toURI(), cookie);

        // Make another HTTP request to the website
        connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        responseCode = connection.getResponseCode();

        // Print response code to console
        System.out.println("Response code: " + responseCode);

        // Retrieve cookies from the cookie manager
        cookies = manager.getCookieStore().getCookies();

        // Print all the cookies
        for (HttpCookie c : cookies) {
            System.out.println(c);
        }
    }
}
