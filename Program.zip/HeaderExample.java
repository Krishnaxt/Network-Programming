import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;

public class HeaderExample {
    public static void main(String[] args) throws Exception {
        URL url = new URL("http://www.example.com");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        Map<String, List<String>> headers = conn.getHeaderFields();

        for (String key : headers.keySet()) {
            System.out.println(key + ": :" + headers.get(key));
        }
    }
}