
import java.net.URI;
import java.net.URISyntaxException;

public class ResolveUris {
    public static void main(String[] args) {
        String baseURIString = "http://www.example.com/path/to/resource";
        String relativeURIString = "../anotherresource";
        try {
            URI baseURI = new URI(baseURIString);
            URI relativeURI = new URI(relativeURIString);
            URI resolvedURI = baseURI.resolve(relativeURI);
            System.out.println("Resolved URI: " + resolvedURI);
        } catch (URISyntaxException e) {
            System.out.println(e.getMessage());
        }
    }
}
