import java.net.*;
import java.io.*;

public class SocOption {
    public static void main(String[] args) throws Exception {
        // Create a new Socket object and connect it to a server
        Socket socket = new Socket("www.google.com", 80);
        // Disable the Nagle algorithm to improve performance
        socket.setOption(SocketOption.TCP_NODELAY, true);
        // Bind the socket to a specific local address
        InetAddress localAddress = InetAddress.getByName("192.168.1.100");
        socket.setOption(SocketOption.SO_BINDADDR, localAddress);
        // Set a timeout of 10 seconds for blocking operations
        socket.setOption(SocketOption.SO_TIMEOUT, 10000);
        // Set a linger timeout of 5 seconds
        socket.setOption(SocketOption.SO_LINGER, 5);
        // Increase the send buffer size to 64 KB
        socket.setOption(SocketOption.SO_SNDBUF, 64 * 1024);
        // Increase the receive buffer size to 128 KB
        socket.setOption(SocketOption.SO_RCVBUF, 128 * 1024);
        // Enable TCP keep-alive
        socket.setOption(SocketOption.SO_KEEPALIVE, true);
        // Enable the ability to send and receive out-of-band data
        socket.setOption(SocketOption.OOBINLINE, true);
        // Set the Type of Service field to high priority
        socket.setOption(SocketOption.IP_TOS, 0x10);

        // Create an input stream to read from the socket
        InputStream inputStream = socket.getInputStream();

        // Read from the input stream
        int c;
        while ((c = inputStream.read()) != -1) {
            System.out.print((char) c);
        }

        // Close the socket
        socket.close();
    }
}