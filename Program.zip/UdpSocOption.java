import java.net.DatagramSocket;
import java.net.SocketException;
public class UdpSocOption {
    public static void main(String[] args) {
        try {
            // Create a UDP socket
            DatagramSocket socket = new DatagramSocket();
            // Set socket options
            socket.setSoTimeout(5000); // Set timeout to 5 seconds
            socket.setReceiveBufferSize(8192); // Set receive buffer size to 8192 bytes
            socket.setSendBufferSize(8192); // Set send buffer size to 8192 bytes
            socket.setReuseAddress(true); // Enable address reuse
            socket.setBroadcast(true); // Enable broadcast capability
            socket.setTrafficClass(0x10); // Set IP TOS to high priority
            // Print the socket options
            System.out.println("Socket options:");
            System.out.println("SO_TIMEOUT: " + socket.getSoTimeout());
            System.out.println("SO_RCVBUF: " + socket.getReceiveBufferSize());
            System.out.println("SO_SNDBUF: " + socket.getSendBufferSize());
            System.out.println("SO_REUSEADDR: " + socket.getReuseAddress());
            System.out.println("SO_BROADCAST: " + socket.getBroadcast());
            System.out.println("IP_TOS: " + socket.getTrafficClass());
            // Close the socket
            socket.close();
        } catch (SocketException e) {
            System.out.println(e.getMessage());
        }
    }
}
