import java.net.*;
public class SocketInfo {
    public static void main(String[] args) throws Exception {
        // Create a new Socket object and connect it to a server
        Socket socket = new Socket("www.google.com", 80);

        // Get information about the socket
        InetAddress remoteAddr = socket.getInetAddress();
        int remotePort = socket.getPort();
        InetAddress localAddr = socket.getLocalAddress();
        int localPort = socket.getLocalPort();

        // Print the socket information
        System.out.println("Remote address: " + remoteAddr);
        System.out.println("Remote port: " + remotePort);
        System.out.println("Local address: " + localAddr);
        System.out.println("Local port: " + localPort);

        // Close the socket
        socket.close();
    }
}
