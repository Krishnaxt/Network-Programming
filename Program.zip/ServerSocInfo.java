import java.net.*;
import java.net.ServerSocket;

public class ServerSocInfo {
    public static void main(String[] args) {
        try {
            ServerSocket srvSoc = new ServerSocket(8080);
            System.out.println("Server socket created. Local port: " + srvSoc.getLocalPort());
            System.out.println("Server socket timeout: " + srvSoc.getSoTimeout());
            System.out.println("Server socket reuse address: " + srvSoc.getReuseAddress());
            System.out.println("Server socket bound address: " + srvSoc.getInetAddress());
            // System.out.println("Number of clients waiting: " + ((Object)
            // srvSoc).getQueueLength());
            srvSoc.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
