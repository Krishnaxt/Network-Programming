import java.net.*;
import java.nio.*;
import java.nio.channels.*;

public class DatagrmChnlServer {
    public static void main(String[] args) throws Exception {
        DatagramChannel channel = DatagramChannel.open();
        channel.bind(new InetSocketAddress("localhost", 12345));
        ByteBuffer buffer = ByteBuffer.allocate(1024);
        while (true) {
            buffer.clear();
            SocketAddress clientAddress = channel.receive(buffer);
            buffer.flip();
            String receivedMessage = new String(buffer.array(), 0, buffer.limit());
            System.out.println("Received from client: " + receivedMessage);
            String responseMessage = "Hello, client!";
            buffer.clear();
            buffer.put(responseMessage.getBytes());
            buffer.flip();
            channel.send(buffer, clientAddress);
        }
    }
}
