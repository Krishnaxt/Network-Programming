import java.io.*;
import java.net.*;
import java.util.*;

public class CachingURL {
    private Map<String, byte[]> cache;

    public CachingURL() {
        this.cache = new HashMap<>();
    }

    public byte[] get(String url) {
        if (cache.containsKey(url)) {
            System.out.println("Retrieving " + url + " from cache...");
            return cache.get(url);
        } else {
            System.out.println("Downloading " + url + "...");
            try {
                URL u = new URL(url);
                HttpURLConnection conn = (HttpURLConnection) u.openConnection();
                byte[] content = readStream(conn.getInputStream());
                add(url, content);
                return content;
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }
    }

    public void add(String url, byte[] content) {
        System.out.println("Adding " + url + " to cache...");
        cache.put(url, content);
    }

    private byte[] readStream(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        int len;
        while ((len = in.read(buffer)) != -1) {
            out.write(buffer, 0, len);
        }
        in.close();
        return out.toByteArray();
    }
}
