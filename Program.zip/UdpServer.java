import java.net.*;

public class UdpServer {
    public static void main(String[] args) throws Exception {
        DatagramSocket serverSocket = new DatagramSocket(12345);
        byte[] receiveData = new byte[1024];
        byte[] sendData;
        while (true) {
            DatagramPacket receivePacket = new DatagramPacket(receiveData,
                    receiveData.length);
            serverSocket.receive(receivePacket);
            String message = new String(receivePacket.getData());
            InetAddress clientAddress = receivePacket.getAddress();
            int clientPort = receivePacket.getPort();
            String responseMessage = "Hello, client!";
            sendData = responseMessage.getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sendData,
                    sendData.length, clientAddress, clientPort);
            serverSocket.send(sendPacket);
            receiveData = new byte[1024]; // Clear the buffer for the next iteration
        }
    }
}
