import javax.net.ssl.SSLSocketFactory;
import java.io.IOException;
import java.net.Socket;
public class Testtt {
    public static void main(String[] args) {
        try {
            // Create the SSL socket factory
            SSLSocketFactory factory = (SSLSocketFactory) SSLSocketFactory.getDefault();
            // Create a secure socket
            Socket socket = factory.createSocket("localhost", 7000);
            // Use the socket for further communication
            // ...

            // Close the socket
            socket.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
