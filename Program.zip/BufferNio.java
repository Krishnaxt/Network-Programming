import java.nio.ByteBuffer;
public class BufferNio {
    public static void main(String[] args) {
        // Create a buffer with a capacity of 10 bytes
        ByteBuffer buffer = ByteBuffer.allocate(10);

        // Write array data into the buffer
        byte[] dataArray = { 1, 2,3,4,5};
        buffer.put(dataArray);
        // System.out.println("Position:"+buffer.position());
        // System.out.println("Limit:"+buffer.limit());
        // System.out.println("Capacity:"+buffer.capacity());
        // Reset the buffer's position and limit for reading
        buffer.flip();
        // pullout data from buffer
        while (buffer.hasRemaining()) {
            System.out.println(buffer.get());
        }

    }
}
