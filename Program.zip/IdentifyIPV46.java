import java.net.*;
import java.net.UnknownHostException;
public class IdentifyIPV46 {
    public static void main(String[] args) {
        try {
            InetAddress address = InetAddress.getByName("www.google.com");
            System.out.println("Host Name: " + address.getHostName());
            System.out.println("IP Address: " + address.getHostAddress());

            if (address instanceof Inet4Address) {
                System.out.println("Type: IPv4");
            } else if (address instanceof Inet6Address) {
                System.out.println("Type: IPv6");
            }
        } catch (UnknownHostException e) {
            System.err.println("Cannot resolve the host name.");
            e.printStackTrace();
        }
    }
}
