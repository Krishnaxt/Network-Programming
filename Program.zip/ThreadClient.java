
import java.io.*;
import java.net.*;

public class ThreadClient {
    public static void main(String[] args) throws IOException {
        Socket socket = new Socket("localhost", 8080);
        DataInputStream in = new DataInputStream(socket.getInputStream());
        DataOutputStream out = new DataOutputStream(socket.getOutputStream());
        String message = "Hello, server!";
        out.writeUTF(message);
        String response = in.readUTF();
        System.out.println(response);
        in.close();
        out.close();
        socket.close();
    }
}
