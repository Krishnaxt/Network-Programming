import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
public class ConsWithOutBind {
    public static void main(String[] args) {
        try {
            // create a server socket without binding it to an address or port
            ServerSocket serverSocket = new ServerSocket();
            // bind the server socket to a specific address and port with the default queue length
            InetSocketAddress endpoint1 = new InetSocketAddress("localhost", 8080);
            serverSocket.bind(endpoint1);
            System.out.println("Server socket bound to " + endpoint1);
            // bind the server socket to another address and port with a queue length of 50
            InetSocketAddress endpoint2 = new InetSocketAddress("192.168.0.10", 9090);
            serverSocket.bind(endpoint2, 50);
            System.out.println("Server socket bound to " + endpoint2 + " with queue length 50");
            // handle incoming connections...

            // close the server socket when done
            serverSocket.close();
        } catch (IOException e) {
            System.err.println("Error creating server socket: " + e.getMessage());
        }
    }
}
