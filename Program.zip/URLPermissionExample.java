import java.net.*;
import java.security.Permission;
import java.io.*;
public class URLPermissionExample {
    public static void main(String[] args) {
        try {
            // Create URL object
            URL url = new URL("https://www.example.com");
            // Open connection to URL
            URLConnection connection = url.openConnection();
            // Check if the calling code has permission to connect
            Permission permission = connection.getPermission();
            if (permission != null) {
                System.out.println("Permission granted: " + permission.getName());
            } else {
                System.out.println("No permission required to connect");
            }
        } catch (IOException e) {
            System.err.println("IOException: " + e.getMessage());
        }
    }
}
