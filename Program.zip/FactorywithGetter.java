class NetworkFactory {
    private String macAddress;
    private String ipAddress;
    private int speed;

    public NetworkFactory(String macAddress, String ipAddress, int speed) {
        this.macAddress = macAddress;
        this.ipAddress = ipAddress;
        this.speed = speed;
    }

    public static NetworkFactory create(String interfaceType) {
        if (interfaceType.equals("ethernet")) {
            return new NetworkFactory("00:11:22:33:44:55", "192.168.0.1", 1000);
        } else if (interfaceType.equals("wifi")) {
            return new NetworkFactory("AA:BB:CC:DD:EE:FF", "192.168.1.1", 300);
        } else {
            throw new IllegalArgumentException("Unknown interface type: " + interfaceType);
        }
    }

    public String getMacAddress() {
        return this.macAddress;
    }

    public String getIpAddress() {
        return this.ipAddress;
    }

    public int getSpeed() {
        return this.speed;
    }

    public void setMacAddress(String macAddress) {
        this.macAddress = macAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }
}

class FactorywithGetter {
    public static void main(String[] args) {
        System.out.println("test");
        NetworkFactory obj = NetworkFactory.create("wifi");
        System.out.println("Wifi: " + obj.getMacAddress());
        NetworkFactory obj1 = new NetworkFactory("234234234234", "192.168.5.2", 120);
        System.out.println("New" + obj1.getMacAddress());

    }
}