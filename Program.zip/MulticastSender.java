import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;

public class MulticastSender {
    public static void main(String[] args) {
        try {
            InetAddress group = InetAddress.getByName("224.0.0.1"); // Multicast group address
            int port = 8888; // Multicast group port
            MulticastSocket socket = new MulticastSocket();
            socket.setTimeToLive(1); // Set the time-to-live for multicast packets
            String message = "Hello, multicast!";
            byte[] data = message.getBytes();
            DatagramPacket packet = new DatagramPacket(data, data.length, group, port);
            socket.send(packet);
            System.out.println("Multicast message sent.");
            socket.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
