import javax.net.ssl.*;
import java.io.*;

public class SSLClient {
    public static void main(String[] args) {
        try {
            // Set up SSL context
            System.setProperty("javax.net.ssl.trustStore", "client.keystore");
            System.setProperty("javax.net.ssl.trustStorePassword", "aaaaaa");

            
            // Create SSL socket
            SSLSocketFactory socketFactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
            SSLSocket socket = (SSLSocket) socketFactory.createSocket("localhost", 8000);
            System.out.println("Connected to server.");
            // Create input and output streams

            DataInputStream in = new DataInputStream(socket.getInputStream());
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            // Send a message to the server
            out.writeUTF("Hello, server!");
            // Read the server's response
            String response = in.readUTF();
            System.out.println("Received response from server: " + response);
            // Close the socket
            socket.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
