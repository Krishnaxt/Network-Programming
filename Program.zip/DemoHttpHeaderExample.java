import java.io.*;
import java.net.*;
import java.util.*;

public class DemoHttpHeaderExample {
    public static void main(String[] args) throws IOException {
        String urlStr = "https://example.com";
        URL url = new URL(urlStr);

        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        int responseCode = conn.getResponseCode();
        System.out.println("Response Code: " + responseCode);

        Map<String, List<String>> headers = conn.getHeaderFields();
        for (String key : headers.keySet()) {
            System.out.println(key + ": " + headers.get(key));
        }
    }
}