
import java.net.ServerSocket;
import java.io.IOException;
public class ServerSocOpt {
    public static void main(String[] args) throws IOException {
        ServerSocket srvSoc = new ServerSocket(8080);
        // set the socket options
        srvSoc.setSoTimeout(10000); 
        srvSoc.setReuseAddress(true); // enable reuse of local address
        srvSoc.setReceiveBufferSize(1024*1024); // set receive buffer size to 1 MB
        
        // retrieve and display the socket options
        System.out.println("Timeout: " + srvSoc.getSoTimeout() + " ms");
        System.out.println("Reuse address: " + srvSoc.getReuseAddress());
        System.out.println("Receive buffer size: " + srvSoc.getReceiveBufferSize() + " bytes");
        srvSoc.close();
    }
}
