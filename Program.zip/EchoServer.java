import java.io.*;
import java.net.*;
import java.util.Scanner;

public class EchoServer {
    public static void main(String[] args) throws IOException {
        try (
                ServerSocket serverSocket = new ServerSocket(8000)) {
            System.out.println("Echo server started.");
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Accepted connection from " + clientSocket.getInetAddress());
                Thread thread = new Thread(new EchoThread(clientSocket));
                thread.start();
            }
        }
    }
}

class EchoThread implements Runnable {
    private final Socket clientSocket;

    public EchoThread(Socket clientSocket) {
        this.clientSocket = clientSocket;
    }

    public void run() {
        try {
            DataInputStream in = new DataInputStream(clientSocket.getInputStream());
            DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream());
            Scanner sc = new Scanner(System.in);
            while (true) {
                String message = in.readUTF();
                System.out.println("Received message from Client: " + clientSocket.getInetAddress() + ": " + message);
                System.out.println("Enter a Message");
                String msg = sc.nextLine();
                // out.writeUTF(message);
                out.writeUTF(msg);
                out.flush();
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
