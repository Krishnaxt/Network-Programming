import java.net.*;
import java.nio.*;
import java.nio.channels.*;
public class DatagrmChnlClient {
    public static void main(String[] args) throws Exception {
        DatagramChannel channel = DatagramChannel.open();
        String message = "Hello, server!";
        ByteBuffer buffer = ByteBuffer.wrap(message.getBytes());
        channel.send(buffer, new InetSocketAddress("localhost", 12345));
        buffer.clear();
        channel.receive(buffer);
        buffer.flip();
        String receivedMessage = new String(buffer.array(), 0, buffer.limit());
        System.out.println("Received from server: " + receivedMessage);
        channel.close();
    }
}
