import java.io.*;
import java.net.*;

public class ClientDemo {
    public static void main(String[] args) {
        String serverAddress = "www.example.com";
        int serverPort = 80;

        try (Socket socket = new Socket(serverAddress, serverPort)) {
            OutputStream output = socket.getOutputStream();
            String message = "Hello, server!";
            output.write(message.getBytes());

            InputStream input = socket.getInputStream();
            byte[] buffer = new byte[1024];
            int bytesRead = input.read(buffer);
            String response = new String(buffer, 0, bytesRead);
            System.out.println("Server response: " + response);

            socket.close();
        } catch (IOException ex) {
            System.err.println("Failed to connect to the server: " + ex.getMessage());
        }
    }
}
