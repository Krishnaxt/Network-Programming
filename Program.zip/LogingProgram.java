
import java.util.logging.*;
public class LogingProgram {
    private static final Logger logger = Logger.getLogger(LogingProgram.class.getName());

    public static void main(String[] args) {
        // configure logger
        logger.setLevel(Level.ALL);
        ConsoleHandler consoleHandler = new ConsoleHandler();
        consoleHandler.setLevel(Level.ALL);
        logger.addHandler(consoleHandler);
        // log messages
        logger.info("Starting application...");
        try {
            int result = divide(10, 0);
            logger.info("Division result: " + result);
        } catch (ArithmeticException e) {
            logger.log(Level.SEVERE, "Division error: " + e.getMessage(), e);
        }
        logger.info("Shutting down application...");
    }

    public static int divide(int num1, int num2) throws ArithmeticException {
        logger.entering(LogingProgram.class.getName(), "divide", new Object[] { num1, num2 });
        if (num2 == 0) {
            throw new ArithmeticException("Cannot divide by zero.");
        }
        int result = num1 / num2;
        logger.exiting(LogingProgram.class.getName(), "divide", result);
        return result;
    }
}
