import java.io.IOException;
import java.net.*;
import java.io.*;

public class ProxySys {
    public static void main(String[] args) {
        // Set HTTP proxy settings
        System.setProperty("http.proxyHost", "116.203.206.103");
        System.setProperty("http.proxyPort", "8080");
        // Create a URL connection
        try {
            URL url = new URL("https://www.facebook.com");
            URLConnection conn = url.openConnection();
            conn.connect();
            // Read the response
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                System.out.println(inputLine);
            }
            in.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
            ;
        }
    }
}
