import java.nio.ByteBuffer;
import java.util.Arrays;

public class SliceBuffer {
    public static void main(String[] args) {
        // Create a byte buffer with a capacity of 8 bytes
        ByteBuffer buffer = ByteBuffer.allocate(3);
        // Write data to the buffer
        buffer.put((byte) 2);
        buffer.put((byte) 5);
        buffer.put((byte) 7);
        System.out.println(buffer.toString());
        buffer.position(0);
        System.out.println(buffer.toString());
        ByteBuffer sliceBuffer = buffer.slice();
        System.out.println(sliceBuffer.toString());
        // Read and print the contents of the slice buffer
        System.out.println("The main buffer is: " + Arrays.toString(sliceBuffer.array()));
        System.out.println("The slic buffer is: " + Arrays.toString(buffer.array()));
    }
}
