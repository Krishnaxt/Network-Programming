import java.io.*;
import java.net.*;

public class TelNetClient {
    public static void main(String[] args) throws IOException {
        String serverAddress = "localhost";
        int portNumber = 23;

        Socket socket = new Socket(serverAddress, portNumber);
        InputStream inputStream = socket.getInputStream();
        OutputStream outputStream = socket.getOutputStream();
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

        String command = "date\n";
        outputStream.write(command.getBytes());
        outputStream.flush();

        String response = reader.readLine();
        System.out.println("Server response: " + response);

        reader.close();
        outputStream.close();
        inputStream.close();
        socket.close();
    }
}
