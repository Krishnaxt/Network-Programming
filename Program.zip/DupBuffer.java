import java.nio.ByteBuffer;
import java.util.Arrays;

public class DupBuffer {
  public static void main(String[] args) {
    // initialize buffer instance
    ByteBuffer sourceBuffer = ByteBuffer.allocate(5);
    // add values to buffer
    sourceBuffer.put((byte) 2);
    sourceBuffer.put((byte) 4);
    sourceBuffer.put((byte) 10);

    // create a duplicate buffer
    ByteBuffer newBuffer = sourceBuffer.duplicate();
    // Print buffers
    System.out.println("The source buffer is: " + Arrays.toString(sourceBuffer.array()));
    System.out.println("The duplicate buffer is: " + Arrays.toString(newBuffer.array()));
    // add values to source buffer
    sourceBuffer.put((byte) 5);
    sourceBuffer.put((byte) 20);
    // Print buffers
    System.out.println("\nThe updated source buffer is: " + Arrays.toString(sourceBuffer.array()));
    System.out.println("The updated duplicate buffer is: " + Arrays.toString(newBuffer.array()));

  }
}