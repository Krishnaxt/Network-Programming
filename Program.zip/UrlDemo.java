import java.net.URL;
public class UrlDemo {
    public static void main(String[] args) {
        try {
            //String urlString = "https://example.com";
            // String urlString = "https://example.com/search?q=java";
             String urlString ="https://www.example.com:8080/path/to/page?query1=value1&query2=value2#section1";
            URL url = new URL(urlString);
            System.out.println("Protocol: " + url.getProtocol());
            System.out.println("Host: " + url.getHost());
            System.out.println("Port: " + url.getPort());
            System.out.println("Path: " + url.getPath());
            System.out.println("Query: " + url.getQuery());
            System.out.println("Fragment: " + url.getRef());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
