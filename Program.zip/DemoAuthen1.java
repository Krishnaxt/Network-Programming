import java.io.*;
import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.net.URL;
import java.net.URLConnection;
public class DemoAuthen1 {
    public static void main(String[] args) throws Exception {
        // Set the URL and create a connection
        URL url = new URL("https://www.example.com");
        URLConnection connection = url.openConnection();
        // Set the username and password
        String username = "Admin";
        String password = "123";
        // Create an Authenticator object to handle authentication
        Authenticator.setDefault(new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password.toCharArray());
            }
        });
        // Read the response from the server
        BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        String inputLine;
        StringBuilder response = new StringBuilder();
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        // Print the response from the server
        System.out.println(response.toString());
    }
}
