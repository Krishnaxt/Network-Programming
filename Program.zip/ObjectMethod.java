import java.nio.ByteBuffer;

public class ObjectMethod {
    public static void main(String[] args) {
        ByteBuffer buffer1 = ByteBuffer.allocate(4);
        ByteBuffer buffer2 = ByteBuffer.allocate(4);
        // Set data in buffers
        buffer1.putInt(123);
        buffer2.putInt(123);
        // Comparing buffers for equality
        boolean areEqual = buffer1.equals(buffer2);
        System.out.println("Buffers are equal: " + areEqual);
        // Hash codes of buffers
        int hashCode1 = buffer1.hashCode();
        int hashCode2 = buffer2.hashCode();
        System.out.println("Hash code of buffer1: " + hashCode1);
        System.out.println("Hash code of buffer2: " + hashCode2);
        // String representation of buffers
        String buffer1String = buffer1.toString();
        String buffer2String = buffer2.toString();
        System.out.println("Buffer1: " + buffer1String);
        System.out.println("Buffer2: " + buffer2String);
    }
}
