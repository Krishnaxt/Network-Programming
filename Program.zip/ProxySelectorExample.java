import java.net.*;
import java.util.*;
import java.io.*;
public class ProxySelectorExample {

   public static void main(String[] args) throws Exception {
      // Create a URL object
      URL url = new URL("https://www.example.com");
      // Get the default proxy selector
      ProxySelector selector = ProxySelector.getDefault();
      // Get a list of proxies for the URL
      URI uri = url.toURI();
      List<Proxy> proxies = selector.select(uri);
      // Print the list of proxies
      System.out.println("Proxies: " + proxies);

      // Create a connection using the first proxy in the list
      Proxy proxy = proxies.get(0);
      HttpURLConnection conn = (HttpURLConnection) url.openConnection(proxy);

      // Set the request method
      conn.setRequestMethod("GET");

      // Read the response from the server
      BufferedReader in = new BufferedReader(
         new InputStreamReader(conn.getInputStream()));
      String inputLine;
      StringBuilder response = new StringBuilder();
      while ((inputLine = in.readLine()) != null) {
         response.append(inputLine);
      }
      in.close();

      // Print the response from the server
      System.out.println(response.toString());
   }
}
