
import java.nio.ByteBuffer;
public class BufferCompack {
    public static void main(String[] args) {
        // Create a byte buffer with a capacity of 8 bytes
        ByteBuffer buffer = ByteBuffer.allocate(3);
        // Write 6 bytes to the buffer
        buffer.put((byte) 1);
        buffer.put((byte) 2);
        buffer.put((byte) 3);
        // Compact the buffer to make room for new data
        buffer.compact();
        // Write 3 bytes to the buffer
        buffer.put((byte) 7);
        buffer.put((byte) 8);
        buffer.put((byte) 9);

        // Flip the buffer for reading
        buffer.flip();
        // Read and print the contents of the buffer
        while (buffer.hasRemaining()) {
            System.out.println(buffer.get());
        }
    }
}
