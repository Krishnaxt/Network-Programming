import java.net.HttpURLConnection;
import java.net.URL;

public class UsingProxy {
    public static void main(String[] args) throws Exception {
        URL url = new URL("http://www.example.com");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();

        boolean usingProxy = connection.usingProxy();
        if (usingProxy) {
            System.out.println("Using a proxy server");
        } else {
            System.out.println("Not using a proxy server");
        }
    }
}