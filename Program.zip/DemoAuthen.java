import java.net.Authenticator;
import java.net.PasswordAuthentication;
import javax.swing.JOptionPane;

public class DemoAuthen extends Authenticator {
    protected PasswordAuthentication getPasswordAuthentication() {
        String username = JOptionPane.showInputDialog("Username:");
        String password = new String(JOptionPane.showInputDialog("Password:").toCharArray());
        return new PasswordAuthentication(username, password.toCharArray());
    }

    public static void main(String[] args) {
        DemoAuthen bo = new DemoAuthen();
        PasswordAuthentication x = bo.getPasswordAuthentication();
        System.out.println(x.getUserName());
    }
}