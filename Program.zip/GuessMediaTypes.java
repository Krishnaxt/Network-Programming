import java.net.URL;
import java.net.URLConnection;
import java.io.IOException;
public class GuessMediaTypes {
    public static void main(String[] args) {
        try {
            URL url = new URL("https://mechicampus.edu.np/wp-content/uploads/2020/01/BBA-lesson-plan.docx");
            URLConnection connection = url.openConnection();
            String contentType = URLConnection.guessContentTypeFromName(url.getFile());
            System.out.println("MIME type: " + contentType);
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
