import java.net.*;
public class InetAddressExample {
    public static void main(String[] args) throws Exception {
        try {
            // Resolve the IP address of a host
            InetAddress address = InetAddress.getByName("www.mechicampus.edu.np");
            System.out.println("IP address: " + address.getHostAddress());

            // Get the hostname of the local machine
            InetAddress localHost = InetAddress.getLocalHost();
            System.out.println("Local hostname: " + localHost.getHostName());

            // Check if an IP address is reachable
            if (address.isReachable(5000)) {
                System.out.println("www.mechicampus.edu.np is reachable");
            } else {
                System.out.println("www.mechicampus.edu.np is not reachable");
            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
