import java.io.*;
import java.net.*;
public class SomeUrlMethod {
    public static void main(String[] args) throws Exception {
        // Create a URL object
        URL url = new URL("https://www.example.com");
        // Open a connection to the URL
        URLConnection connection = url.openConnection();
        // Set some properties of the connection
        connection.setConnectTimeout(5000);
        connection.setReadTimeout(10000);
        connection.setDoInput(true);
        connection.setDoOutput(false);
        // Print out some information about the connection
        System.out.println("Content Type: " + connection.getContentType());
        System.out.println("Content Length: " + connection.getContentLength());
        System.out.println("Allow User Interaction: " + connection.getAllowUserInteraction());
        System.out.println("Do Input: " + connection.getDoInput());
        System.out.println("Do Output: " + connection.getDoOutput());
        System.out.println("If Modified Since: " + connection.getIfModifiedSince());
        // Get the input stream from the connection and read the response
        BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        String inputLine;
        while ((inputLine = in.readLine()) != null) {
            System.out.println(inputLine);
        }
        in.close();
    }
}