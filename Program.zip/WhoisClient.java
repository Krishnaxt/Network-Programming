import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
public class WhoisClient extends JFrame implements ActionListener {
    private JTextField domainField;
    private JTextArea resultArea;
    public WhoisClient() {
        super("Whois Client");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        domainField = new JTextField();
        add(domainField, BorderLayout.NORTH);
        resultArea = new JTextArea();
        add(new JScrollPane(resultArea), BorderLayout.CENTER);
        JButton lookupButton = new JButton("Lookup");
        lookupButton.addActionListener(this);
        add(lookupButton, BorderLayout.SOUTH);
        setSize(400, 300);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String domain = domainField.getText();
        String result = lookup(domain);
        resultArea.setText(result);
    }
    private String lookup(String domain) {
        try {
            Socket socket = new Socket("whois.internic.net", 43);
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            DataInputStream in = new DataInputStream(socket.getInputStream());
            out.writeUTF(domain);
            String response = in.readUTF();
            socket.close();
            return response;
        } catch (IOException e) {
            return "Error: " + e.getMessage();
        }
    }
    public static void main(String[] args) {
        new WhoisClient();
    }
}
