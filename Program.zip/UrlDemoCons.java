
import java.net.URL;
import java.net.MalformedURLException;

public class UrlDemoCons {
    public static void main(String[] args) {
        try {
            // Construct a URL from a string
            URL url1 = new URL("https://example.com/path/to/page");

            // Construct a URL from a protocol, hostname, and file
            URL url2 = new URL("https", "example.com", "/path/to/page");

            // Construct a URL from a protocol, host, port, and file
            URL url3 = new URL("https", "example.com", 8080, "/path/to/page");

            // Construct a URL from a base URL and a relative URL
            URL baseURL = new URL("https://example.com/path/to/");
            URL url4 = new URL(baseURL, "page");

            // Print out the various URLs
            System.out.println("URL 1: " + url1.toString());
            System.out.println("URL 2: " + url2.toString());
            System.out.println("URL 3: " + url3.toString());
            System.out.println("URL 4: " + url4.toString());

        } catch (MalformedURLException e) {
            System.out.println(e.getMessage());
        }
    }
}
