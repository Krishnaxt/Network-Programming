import javax.net.ssl.SSLServerSocketFactory;
public class CipherSuit {
    public static void main(String[] args) {
        String[] cipherSuites = ((SSLServerSocketFactory) 
        SSLServerSocketFactory.getDefault()).getSupportedCipherSuites();
        for (String suite : cipherSuites) {
            System.out.println(suite);
        }
    }
}
