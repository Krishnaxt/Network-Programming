class CarFactory {
    private String make;

    public CarFactory(String make) {
        this.make = make;
    }

    public static CarFactory create(String make) {
        if (make.equals("Ford")) {
            return new CarFactory(make);
        } else if (make.equals("Netavi")) {
            return new CarFactory(make);
        } else {
            throw new IllegalArgumentException("Unsupported make: " + make);
        }
    }

    public static void main(String[] args) {
        CarFactory mustang = CarFactory.create("Ford");
        System.out.println(mustang.make);
        CarFactory cg = CarFactory.create("Netavi");
        System.out.println(cg.make);
    }
}