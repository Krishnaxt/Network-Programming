import javax.swing.*;
public class DemoPass1 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Password Field Example");
        JPasswordField passwordField = new JPasswordField(10);
        passwordField.setEchoChar('*');

        JPanel panel = new JPanel();
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);

        frame.add(panel);
        frame.setSize(200, 100);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Get the password entered in the password field  
        ///char[] password = passwordField.getPassword();
        //System.out.println("Password: " + new String(password)); 

    }
}
