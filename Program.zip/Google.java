
//A program that prints the address of www.mechicampus.edu.com
import java.net.*;
public class Google {
    public static void main(String[] args) throws UnknownHostException {
        try {
            InetAddress address = InetAddress.getByName("www.mechicampus.edu.np");
            System.out.println("getByName():" + address);
            InetAddress localladdr = InetAddress.getLocalHost();
            System.out.println("getLocalHost():" + localladdr);
            InetAddress[] addresses = InetAddress.getAllByName("www.facebook.com");
            for (InetAddress addritem : addresses) {
                System.out.println(addritem);
            }
        } catch (UnknownHostException ex) {
            System.out.println("Could not find mechicampus.com ");
        }
    }
}