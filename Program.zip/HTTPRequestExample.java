import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public class HTTPRequestExample {
    public static void main(String[] args) throws IOException {
        URL url = new URL("https://mechicampus.edu.np");
        HttpURLConnection con = (HttpURLConnection) url.openConnection();

        con.setRequestMethod("GET");
        con.setRequestProperty("User-Agent", "Mozilla/5.0");
        con.setRequestProperty("Accept", "application/json");
        con.setRequestProperty("Authorization", "Mechi <2543345345>");
        con.setRequestProperty("Content-Type", "application/json");
        con.setRequestProperty("Cache-Control", "no-cache");

        int status = con.getResponseCode();
        // int status = con.getResponseCode();
        System.out.println("Response status: " + status);
    }
}
