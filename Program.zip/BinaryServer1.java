import java.io.*;
import java.net.*;
public class BinaryServer1 {
    public static void main(String[] args) throws IOException {
        int port = Integer.parseInt(args[0]);
        ServerSocket serverSocket = new ServerSocket(port);
        System.out.println("Server started on port 8080");
        while (true) {
            Socket cliSoc = serverSocket.accept();
            System.out.println("Client cocliSocnnected: " + cliSoc.getInetAddress());
            OutputStream out = cliSoc.getOutputStream();
            File file = new File("example.txt");
            FileInputStream fin = new FileInputStream(file);
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = fin.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }
            out.close();
            fin.close();
            cliSoc.close();
            System.out.println("Client disconnected.");
        }
    }
}
