import java.net.*;

public class LocalRemote {
    public static void main(String[] args) throws Exception {
        String hostname = "www.google.com";
        int port = 80;
        try (// Create a socket and connect to the remote server
                Socket socket = new Socket(hostname, port)) {
            // Retrieve the local and remote socket addresses
            InetSocketAddress localAddr = (InetSocketAddress) socket.getLocalSocketAddress();
            InetSocketAddress remoteAddr = (InetSocketAddress) socket.getRemoteSocketAddress();

            // Print the local and remote socket addresses
            System.out.println("Local address: " + localAddr.getAddress().getHostAddress() + ":" + localAddr.getPort());
            System.out.println(
                    "Remote address: " + remoteAddr.getAddress().getHostAddress() + ":" + remoteAddr.getPort());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
