import java.io.*;
import java.net.*;
public class CloseServer {
    public static void main(String[] args) {
        ServerSocket serverSocket = null;
        try {
            serverSocket = new ServerSocket(8080);
            System.out.println("Server is running on port 8080...");
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected: " + clientSocket.getInetAddress().getHostAddress());
                DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream());
                String dateTime = new Date().toString();
                out.writeUTF("Today is :" + dateTime);
                out.close();
                clientSocket.close();
            }
        } catch (IOException e) {
            System.out.println("Server exception: " + e.getMessage());
        } finally {
            // close the server socket when you're done with it
            if (serverSocket != null) {
                try {
                    serverSocket.close();
                } catch (IOException e) {
                    System.out.println(e.getMessage());
                }
            }
        }
    }
}
