import java.io.*;
import java.net.*;

public class ArbitaryHeader {
    public static void main(String[] args) throws IOException {
        String urlStr = "https://example.com";
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        System.out.println("Content-Type::" + conn.getContentType());
        System.out.println("Content-Length::" + conn.getContentLength());
        System.out.println("Expiration-Date::" + conn.getExpiration());
        System.out.println("Last-Modified::" + conn.getLastModified());
        System.out.println("Date::" + conn.getDate());
        System.out.println("Content-encoding::" + conn.getContentEncoding());

    }
}