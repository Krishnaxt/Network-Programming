import java.net.CookieStore;
import java.net.HttpCookie;
import java.net.URI;
import java.util.List;

public class DemoCookie {
    public static void main(String[] args) throws Exception {
        // Create a new cookie with the name "Mechi" and value "12345"
        HttpCookie cookie = new HttpCookie("Mechi", "12345");

        // Set some additional attributes on the cookie
        cookie.setDomain(".example.com");
        cookie.setPath("/");
        cookie.setMaxAge(3600);

        // Add the cookie to the cookie store for the specified URI
        URI uri = new URI("https://www.example.com");
        java.net.CookieManager cookieManager = new java.net.CookieManager();
        cookieManager.getCookieStore().add(uri, cookie);
        System.out.println("Successfully set cookie");
        // Reading cookie from cookieStore
        CookieStore cookieJar = cookieManager.getCookieStore();
        List<HttpCookie> cookies = cookieJar.getCookies();
        for (HttpCookie item : cookies) {
            System.out.println("Name: " + item.getName());
            System.out.println("Value: " + item.getValue());
            System.out.println("Domain: " + item.getDomain());
            System.out.println("Path: " + item.getPath());
            System.out.println("Max-Age: " + item.getMaxAge());
            System.out.println("Secure: " + item.getSecure());
            System.out.println("HttpOnly: " + item.isHttpOnly());
            System.out.println();
        }

    }
}
