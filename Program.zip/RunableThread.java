class RunThread implements Runnable {
    public void run() {
        System.out.println("I am at Runnable at run function:");
    }
}

public class RunableThread {
    public static void main(String[] args) {
        // RunThread rt = new RunThread();
        // rt.run();
        Thread t1 = new Thread(new RunThread());
        t1.start();
    }
}
