import java.nio.ByteBuffer;
public class MakResetBuff {
    public static void main(String[] args) {
        ByteBuffer buffer = ByteBuffer.allocate(10);
        buffer.put((byte) 1);
        buffer.put((byte) 2);
        buffer.put((byte) 3);
        System.out.println("Before Mark:" + buffer.toString());
        buffer.mark(); // Marking the position
        System.out.println("After Mark:" + buffer.toString());
        buffer.put((byte) 4);
        buffer.put((byte) 5);
        System.out.println("Before Reset:" + buffer.toString());
        buffer.reset(); // Resetting to the marked position
        System.out.println("After Reset:" + buffer.toString());
        buffer.put((byte) 6);
        buffer.put((byte) 7);
    }
}