import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
public class AdderImp extends UnicastRemoteObject implements Adder {
    protected AdderImp() throws RemoteException {
        super();
    }
    public int add(int a, int b) throws RemoteException {
        return a + b;
    }
}
