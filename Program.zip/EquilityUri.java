import java.net.URI;
import java.net.URISyntaxException;
public class EquilityUri {
    public static void main(String[] args) {
        try {
            // create two URIs to compare
            URI uri1 = new URI("http://www.example.com/path/to/resource?param=value");
            URI uri2 = new URI("http://www.example.com/path/to/resource?param=value");

            // compare URIs for equality
            boolean equal = uri1.equals(uri2);
            System.out.println("URIs are equal: " + equal);

            // compare URIs for relative order
            int compare = uri1.compareTo(uri2);
            if (compare == 0) {
                System.out.println("URIs are equal");
            } else if (compare < 0) {
                System.out.println("uri1 is less than uri2");
            } else {
                System.out.println("uri1 is greater than uri2");
            }
        } catch (URISyntaxException e) {
            System.out.println(e.getMessage());
        }
    }
}
