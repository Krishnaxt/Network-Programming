import java.net.*;
public class UdpClient1 {
    public static void main(String[] args) throws Exception {
        DatagramSocket clientSocket = new DatagramSocket();
        InetAddress serverAddress = InetAddress.getByName("localhost");
        int serverPort = 12345;
        String message = "Hello, server!";
        byte[] sendData = message.getBytes();
        DatagramPacket sendPacket = new DatagramPacket(
                sendData, sendData.length, serverAddress, serverPort);
        clientSocket.send(sendPacket);
        clientSocket.close();
    }
}
