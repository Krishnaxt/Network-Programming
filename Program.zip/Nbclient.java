import java.io.*;
import java.net.*;
import java.nio.*;
import java.nio.channels.*;
import java.util.*;
public class Nbclient {
    private static final String SERVER_HOST = "localhost";
    private static final int SERVER_PORT = 8888;
    public static void main(String[] args) {
        try {
            SocketChannel clientChannel = SocketChannel.open();
            clientChannel.configureBlocking(false);
            clientChannel.connect(new InetSocketAddress(SERVER_HOST, SERVER_PORT));

            while (!clientChannel.finishConnect()) {
                // Wait for the connection to be established
            }
            System.out.println("Connected to server: " + clientChannel.getRemoteAddress());
            System.out.println("Please enter text to communicate with server");
            Scanner scanner = new Scanner(System.in);

            while (true) {
                String message = scanner.nextLine();
                ByteBuffer buffer = ByteBuffer.wrap(message.getBytes());
                clientChannel.write(buffer);
                buffer.clear();
                clientChannel.read(buffer);
                buffer.flip();
                byte[] data = new byte[buffer.limit()];
                buffer.get(data);
                String response = new String(data);
                System.out.println("Received from server: " + response);
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
