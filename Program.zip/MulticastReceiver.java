import java.io.IOException;
import java.net.*;
public class MulticastReceiver {
    public static void main(String[] args) {
        InetAddress multicastGroup;
        int multicastPort = 8888;
        try {
            // Join multicast group
            multicastGroup = InetAddress.getByName("224.0.0.1");
            NetworkInterface networkInterface = NetworkInterface.getByInetAddress(InetAddress.getLocalHost());
            MulticastSocket socket = new MulticastSocket(multicastPort);
            socket.joinGroup(new InetSocketAddress(multicastGroup, multicastPort), networkInterface);
            System.out.println("Joined multicast group: " + multicastGroup.getHostAddress());
            // Receive multicast packets
            byte[] buffer = new byte[1024];
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
            while (true) {
                socket.receive(packet);
                String receivedMessage = new String(packet.getData(), 0, packet.getLength());
                System.out.println("Received multicast message: " + receivedMessage);
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
